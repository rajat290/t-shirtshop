export default function About() {
  return (
    <div className="bg-white">
      <div className="relative isolate overflow-hidden bg-gray-900 py-24 sm:py-32">
        <img
          src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2830&q=80"
          alt=""
          className="absolute inset-0 -z-10 h-full w-full object-cover opacity-20"
        />
        
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl lg:mx-0">
            <h2 className="text-4xl font-bold tracking-tight text-white sm:text-6xl">About Us</h2>
            <p className="mt-6 text-lg leading-8 text-gray-300">
              We're passionate about delivering quality fashion that makes you feel confident and comfortable.
            </p>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-6 lg:px-8 py-24">
        <div className="grid grid-cols-1 gap-16 lg:grid-cols-2">
          <div>
            <h3 className="text-3xl font-bold mb-6">Our Story</h3>
            <p className="text-lg text-gray-600">
              Founded in 2024, we set out to create a brand that combines style, comfort, and sustainability.
              Our journey began with a simple idea: fashion should be accessible, ethical, and expressive.
            </p>
          </div>
          
          <div>
            <h3 className="text-3xl font-bold mb-6">Our Mission</h3>
            <p className="text-lg text-gray-600">
              We're committed to sustainable fashion and ethical manufacturing practices.
              Every piece in our collection is carefully crafted with attention to detail and respect for our environment.
            </p>
          </div>
        </div>

        <div className="mt-24">
          <h3 className="text-3xl font-bold mb-12 text-center">Our Values</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <h4 className="text-xl font-semibold mb-4">Quality</h4>
              <p className="text-gray-600">
                We never compromise on quality, ensuring each product meets our high standards.
              </p>
            </div>
            <div className="text-center">
              <h4 className="text-xl font-semibold mb-4">Sustainability</h4>
              <p className="text-gray-600">
                Environmental responsibility is at the core of everything we do.
              </p>
            </div>
            <div className="text-center">
              <h4 className="text-xl font-semibold mb-4">Community</h4>
              <p className="text-gray-600">
                We believe in building strong relationships with our customers and partners.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}