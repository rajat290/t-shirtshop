import Hero from '@/components/home/Hero';
import ImageSlider from '@/components/home/ImageSlider';
import CategoryGrid from '@/components/categories/CategoryGrid';
import FeaturedProducts from '@/components/home/FeaturedProducts';
import Newsletter from '@/components/home/Newsletter';

export default function Home() {
  return (
    <main>
      <Hero />
      <ImageSlider />
      <CategoryGrid />
      <FeaturedProducts />
      <Newsletter />
    </main>
  );
}