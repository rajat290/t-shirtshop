import { useState } from 'react';
import ProductCard from '@/components/product/ProductCard';
import { Product } from '@/lib/types';
import { Filter, SlidersHorizontal } from 'lucide-react';
import Button from '@/components/ui/Button';

const products: Product[] = [
  {
    id: 1,
    name: 'Classic White T-Shirt',
    description: 'Premium cotton classic fit t-shirt',
    price: 29.99,
    images: ['https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1480&q=80'],
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['White', 'Black', 'Gray'],
    category: 'T-Shirts',
    inStock: true,
  },
  {
    id: 2,
    name: 'Vintage Denim Jacket',
    description: 'Classic denim jacket with a modern twist',
    price: 89.99,
    images: ['https://images.unsplash.com/photo-1551537482-f2075a1d41f2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1480&q=80'],
    sizes: ['S', 'M', 'L'],
    colors: ['Blue', 'Black'],
    category: 'Jackets',
    inStock: true,
  },
  // Add more products...
];

const filters = {
  categories: ['T-Shirts', 'Jackets', 'Hoodies', 'Accessories'],
  sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
  colors: ['White', 'Black', 'Gray', 'Blue', 'Red'],
  priceRanges: ['Under $50', '$50 - $100', '$100 - $200', 'Over $200'],
};

export default function Shop() {
  const [showFilters, setShowFilters] = useState(false);

  return (
    <div className="bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">Shop All Products</h1>
          <Button
            variant="outline"
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2"
          >
            <SlidersHorizontal className="h-4 w-4" />
            Filters
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters */}
          {showFilters && (
            <div className="lg:col-span-1 space-y-6">
              {Object.entries(filters).map(([category, options]) => (
                <div key={category}>
                  <h3 className="text-lg font-medium capitalize mb-4">{category}</h3>
                  <div className="space-y-2">
                    {options.map((option) => (
                      <label key={option} className="flex items-center">
                        <input type="checkbox" className="rounded border-gray-300" />
                        <span className="ml-2">{option}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Product Grid */}
          <div className={showFilters ? 'lg:col-span-3' : 'lg:col-span-4'}>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}