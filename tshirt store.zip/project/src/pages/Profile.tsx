import { useState } from 'react';
import Button from '@/components/ui/Button';
import { User, Package, Heart, CreditCard } from 'lucide-react';

const orders = [
  {
    id: '#12345',
    date: '2024-03-15',
    status: 'Delivered',
    total: 129.99,
    items: [
      { name: 'Classic White T-Shirt', quantity: 2, price: 29.99 },
      { name: 'Denim Jacket', quantity: 1, price: 69.99 },
    ],
  },
  // Add more orders...
];

export default function Profile() {
  const [activeTab, setActiveTab] = useState('profile');

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="space-y-4">
                <button
                  onClick={() => setActiveTab('profile')}
                  className={`flex items-center space-x-2 w-full p-2 rounded-md ${
                    activeTab === 'profile' ? 'bg-gray-100' : ''
                  }`}
                >
                  <User className="h-5 w-5" />
                  <span>Profile</span>
                </button>
                <button
                  onClick={() => setActiveTab('orders')}
                  className={`flex items-center space-x-2 w-full p-2 rounded-md ${
                    activeTab === 'orders' ? 'bg-gray-100' : ''
                  }`}
                >
                  <Package className="h-5 w-5" />
                  <span>Orders</span>
                </button>
                <button
                  onClick={() => setActiveTab('wishlist')}
                  className={`flex items-center space-x-2 w-full p-2 rounded-md ${
                    activeTab === 'wishlist' ? 'bg-gray-100' : ''
                  }`}
                >
                  <Heart className="h-5 w-5" />
                  <span>Wishlist</span>
                </button>
                <button
                  onClick={() => setActiveTab('payment')}
                  className={`flex items-center space-x-2 w-full p-2 rounded-md ${
                    activeTab === 'payment' ? 'bg-gray-100' : ''
                  }`}
                >
                  <CreditCard className="h-5 w-5" />
                  <span>Payment Methods</span>
                </button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              {activeTab === 'profile' && (
                <div>
                  <h2 className="text-2xl font-bold mb-6">Profile Information</h2>
                  <form className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">
                          First Name
                        </label>
                        <input
                          type="text"
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">
                          Last Name
                        </label>
                        <input
                          type="text"
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Email
                      </label>
                      <input
                        type="email"
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black"
                      />
                    </div>
                    <Button type="submit">Save Changes</Button>
                  </form>
                </div>
              )}

              {activeTab === 'orders' && (
                <div>
                  <h2 className="text-2xl font-bold mb-6">Order History</h2>
                  <div className="space-y-6">
                    {orders.map((order) => (
                      <div key={order.id} className="border rounded-lg p-6">
                        <div className="flex justify-between items-center mb-4">
                          <div>
                            <p className="font-medium">Order {order.id}</p>
                            <p className="text-sm text-gray-500">{order.date}</p>
                          </div>
                          <span className="px-3 py-1 rounded-full text-sm bg-green-100 text-green-800">
                            {order.status}
                          </span>
                        </div>
                        <div className="space-y-2">
                          {order.items.map((item, index) => (
                            <div key={index} className="flex justify-between">
                              <p>{item.name} x{item.quantity}</p>
                              <p>${item.price}</p>
                            </div>
                          ))}
                        </div>
                        <div className="mt-4 pt-4 border-t">
                          <div className="flex justify-between">
                            <p className="font-medium">Total</p>
                            <p className="font-medium">${order.total}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'wishlist' && (
                <div>
                  <h2 className="text-2xl font-bold mb-6">Wishlist</h2>
                  <p className="text-gray-500">Your wishlist is empty.</p>
                </div>
              )}

              {activeTab === 'payment' && (
                <div>
                  <h2 className="text-2xl font-bold mb-6">Payment Methods</h2>
                  <Button variant="outline" className="w-full">
                    Add New Payment Method
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}