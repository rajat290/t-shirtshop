import { useState } from 'react';
import { Product } from '@/lib/types';
import { useCart } from '@/lib/context/CartContext';
import Button from '../ui/Button';

interface ProductDetailProps {
  product: Product;
}

export default function ProductDetail({ product }: ProductDetailProps) {
  const [selectedSize, setSelectedSize] = useState(product.sizes[0]);
  const [selectedColor, setSelectedColor] = useState(product.colors[0]);
  const [quantity, setQuantity] = useState(1);
  const { dispatch } = useCart();

  const addToCart = () => {
    dispatch({
      type: 'ADD_ITEM',
      payload: {
        ...product,
        quantity,
        selectedSize,
        selectedColor,
      },
    });
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 gap-x-8 gap-y-10 lg:grid-cols-2">
        {/* Image gallery */}
        <div className="lg:col-span-1">
          <div className="aspect-w-1 aspect-h-1 w-full">
            <img
              src={product.images[0]}
              alt={product.name}
              className="h-full w-full object-cover object-center"
            />
          </div>
          <div className="mt-4 grid grid-cols-4 gap-4">
            {product.images.slice(1).map((image, index) => (
              <div key={index} className="aspect-w-1 aspect-h-1">
                <img
                  src={image}
                  alt={`${product.name} ${index + 2}`}
                  className="h-full w-full object-cover object-center"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Product info */}
        <div className="lg:col-span-1">
          <h1 className="text-2xl font-bold tracking-tight text-gray-900">
            {product.name}
          </h1>
          <div className="mt-4">
            <p className="text-3xl tracking-tight text-gray-900">
              ${product.price}
            </p>
          </div>

          <div className="mt-8">
            <h3 className="text-sm font-medium text-gray-900">Size</h3>
            <div className="mt-2">
              <div className="grid grid-cols-4 gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`flex items-center justify-center rounded-md py-2 text-sm font-medium uppercase
                      ${selectedSize === size
                        ? 'bg-black text-white'
                        : 'bg-white text-gray-900 ring-1 ring-gray-200'
                      }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-8">
            <h3 className="text-sm font-medium text-gray-900">Color</h3>
            <div className="mt-2">
              <div className="grid grid-cols-4 gap-2">
                {product.colors.map((color) => (
                  <button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`flex items-center justify-center rounded-md py-2 text-sm font-medium uppercase
                      ${selectedColor === color
                        ? 'bg-black text-white'
                        : 'bg-white text-gray-900 ring-1 ring-gray-200'
                      }`}
                  >
                    {color}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-8">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-900">Quantity</h3>
              <div className="flex items-center">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="rounded-l-md border border-gray-300 px-3 py-1"
                >
                  -
                </button>
                <span className="border-t border-b border-gray-300 px-4 py-1">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="rounded-r-md border border-gray-300 px-3 py-1"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          <div className="mt-8">
            <Button onClick={addToCart} className="w-full">
              Add to Cart
            </Button>
          </div>

          <div className="mt-8">
            <div className="prose prose-sm text-gray-500">
              <p>{product.description}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}