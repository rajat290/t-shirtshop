import Button from '../ui/Button';

const Newsletter = () => {
  return (
    <section className="bg-gray-100 py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900">
            Subscribe to our newsletter
          </h2>
          <p className="mt-4 text-lg text-gray-600">
            Get the latest updates on new products and upcoming sales.
          </p>
          <form className="mt-8 sm:mx-auto sm:max-w-xl">
            <div className="sm:flex">
              <input
                type="email"
                required
                className="w-full rounded-md border-gray-300 px-5 py-3 placeholder-gray-500 focus:border-black focus:ring-black sm:max-w-xs"
                placeholder="Enter your email"
              />
              <div className="mt-3 sm:mt-0 sm:ml-3">
                <Button type="submit">Subscribe</Button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;