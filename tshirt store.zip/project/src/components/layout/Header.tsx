import { ShoppingCart, User, Search } from 'lucide-react';
import Button from '../ui/Button';

const Header = () => {
  return (
    <header className="border-b bg-white">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4">
        <div className="flex items-center">
          <a href="/" className="text-2xl font-bold">
            STORE
          </a>
        </div>

        <nav className="hidden md:flex items-center space-x-6">
          <a href="/shop" className="text-gray-600 hover:text-black">
            Shop
          </a>
          <a href="/categories" className="text-gray-600 hover:text-black">
            Categories
          </a>
          <a href="/about" className="text-gray-600 hover:text-black">
            About
          </a>
        </nav>

        <div className="flex items-center space-x-4">
          <button className="text-gray-600 hover:text-black">
            <Search className="h-5 w-5" />
          </button>
          <button className="text-gray-600 hover:text-black">
            <User className="h-5 w-5" />
          </button>
          <button className="text-gray-600 hover:text-black relative">
            <ShoppingCart className="h-5 w-5" />
            <span className="absolute -top-2 -right-2 h-4 w-4 rounded-full bg-black text-xs text-white flex items-center justify-center">
              0
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;