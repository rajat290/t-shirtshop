import { useState, useRef } from 'react';
import { CustomDesign } from '@/lib/types';
import Button from '../ui/Button';

interface DesignCustomizerProps {
  onSave: (design: CustomDesign) => void;
}

export default function DesignCustomizer({ onSave }: DesignCustomizerProps) {
  const [design, setDesign] = useState<CustomDesign>({
    imageUrl: '',
    position: 'front',
    scale: 1,
    rotation: 0,
  });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setDesign(prev => ({
          ...prev,
          imageUrl: reader.result as string,
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    onSave(design);
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Upload Design</h3>
          <div className="mt-2">
            <Button
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              className="w-full"
            >
              Choose Image
            </Button>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium text-gray-900">Position</h3>
          <div className="mt-2 grid grid-cols-2 gap-4">
            <Button
              variant={design.position === 'front' ? 'primary' : 'outline'}
              onClick={() => setDesign(prev => ({ ...prev, position: 'front' }))}
            >
              Front
            </Button>
            <Button
              variant={design.position === 'back' ? 'primary' : 'outline'}
              onClick={() => setDesign(prev => ({ ...prev, position: 'back' }))}
            >
              Back
            </Button>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium text-gray-900">Scale</h3>
          <input
            type="range"
            min="0.5"
            max="2"
            step="0.1"
            value={design.scale}
            onChange={(e) => setDesign(prev => ({
              ...prev,
              scale: parseFloat(e.target.value),
            }))}
            className="w-full mt-2"
          />
        </div>

        <div>
          <h3 className="text-lg font-medium text-gray-900">Rotation</h3>
          <input
            type="range"
            min="-180"
            max="180"
            value={design.rotation}
            onChange={(e) => setDesign(prev => ({
              ...prev,
              rotation: parseInt(e.target.value),
            }))}
            className="w-full mt-2"
          />
        </div>

        {design.imageUrl && (
          <div className="relative aspect-w-1 aspect-h-1 bg-gray-100 rounded-lg">
            <img
              src={design.imageUrl}
              alt="Preview"
              className="object-contain"
              style={{
                transform: `scale(${design.scale}) rotate(${design.rotation}deg)`,
              }}
            />
          </div>
        )}

        <Button
          onClick={handleSave}
          className="w-full"
          disabled={!design.imageUrl}
        >
          Save Design
        </Button>
      </div>
    </div>
  );
}