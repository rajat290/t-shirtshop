import { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { CartProvider } from './lib/context/CartContext';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import Home from './pages/Home';
import Shop from './pages/Shop';
import About from './pages/About';
import Contact from './pages/Contact';
import Profile from './pages/Profile';
import AuthForm from './components/auth/AuthForm';
import CartDrawer from './components/cart/CartDrawer';
import DesignCustomizer from './components/customizer/DesignCustomizer';

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);

  const handleLogin = (data: any) => {
    console.log('Login data:', data);
    // Implement login logic here
  };

  const handleRegister = (data: any) => {
    console.log('Register data:', data);
    // Implement register logic here
  };

  const handleSaveDesign = (design: any) => {
    console.log('Saved design:', design);
    // Implement design saving logic here
  };

  return (
    <CartProvider>
      <Router>
        <div className="min-h-screen bg-white">
          <Header onCartClick={() => setIsCartOpen(true)} />
          <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
          
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/shop" element={<Shop />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/profile" element={<Profile />} />
            <Route
              path="/login"
              element={
                <div className="max-w-md mx-auto mt-16 px-4">
                  <h1 className="text-3xl font-bold text-center mb-8">Sign In</h1>
                  <AuthForm type="login" onSubmit={handleLogin} />
                </div>
              }
            />
            <Route
              path="/register"
              element={
                <div className="max-w-md mx-auto mt-16 px-4">
                  <h1 className="text-3xl font-bold text-center mb-8">Create Account</h1>
                  <AuthForm type="register" onSubmit={handleRegister} />
                </div>
              }
            />
            <Route
              path="/customize"
              element={
                <div className="max-w-4xl mx-auto mt-16 px-4">
                  <h1 className="text-3xl font-bold text-center mb-8">Customize Your Design</h1>
                  <DesignCustomizer onSave={handleSaveDesign} />
                </div>
              }
            />
          </Routes>

          <Footer />
        </div>
      </Router>
    </CartProvider>
  );
}

export default App;