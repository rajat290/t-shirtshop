export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  images: string[];
  sizes: string[];
  colors: string[];
  category: string;
  inStock: boolean;
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
}

export interface CustomDesign {
  imageUrl: string;
  position: 'front' | 'back';
  scale: number;
  rotation: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  savedDesigns: CustomDesign[];
}